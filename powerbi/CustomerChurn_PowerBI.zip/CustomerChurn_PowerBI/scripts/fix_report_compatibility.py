"""PBIR runtime compatibility repair, using Microsoft CLI 0.5.0 scaffold metadata."""
import json,uuid,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
REPORT=ROOT/'CustomerChurn.Report'
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,j):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(j,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def url(part):return 'https://developer.microsoft.com/json-schemas/fabric/'+part+'/schema.json'
version=REPORT/'definition/version.json';j=load(version);j['version']='2.0.0';save(version,j)
platform=REPORT/'.platform'
j=load(platform) if platform.exists() else {'$schema':url('gitIntegration/platformProperties/2.0.0'),'metadata':{'type':'Report','displayName':'Customer Churn'},'config':{'version':'2.0','logicalId':str(uuid.uuid4())}}
save(platform,j)
theme='Fluent2-CY26SU10'
asset=ROOT/'scripts/assets'/ (theme+'.json')
out=REPORT/'StaticResources/SharedResources/BaseThemes'/(theme+'.json');out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(asset,out)
report=REPORT/'definition/report.json'
j=load(report);j['$schema']=url('item/report/definition/report/3.3.0')
j['themeCollection']={'baseTheme':{'name':theme,'reportVersionAtImport':{'visual':'2.11.0','report':'3.4.0','page':'2.3.1'},'type':'SharedResources'}}
j['resourcePackages']=[{'name':'SharedResources','type':'SharedResources','items':[{'name':theme,'path':'BaseThemes/'+theme+'.json','type':'BaseTheme'}]}]
j['settings']={'useStylableVisualContainerHeader':True,'exportDataMode':'AllowSummarized','defaultDrillFilterOtherVisuals':True,'allowChangeFilterTypes':True,'useEnhancedTooltips':True,'useDefaultAggregateDisplayName':True}
save(report,j)
pages=REPORT/'definition/pages/pages.json';j=load(pages);j['$schema']=url('item/report/definition/pagesMetadata/1.1.0');save(pages,j)
for p in (REPORT/'definition/pages').rglob('page.json'):
 j=load(p);j['$schema']=url('item/report/definition/page/2.1.0');save(p,j)
for p in (REPORT/'definition/pages').rglob('visual.json'):
 j=load(p);j['$schema']=url('item/report/definition/visualContainer/2.9.0')
 if j.get('visual',{}).get('visualType')=='card':
  v=j['visual'];v['visualType']='cardVisual';q=v['query']['queryState'];q['Data']=q.pop('Values')
 save(p,j)
print('PBIR metadata correction applied; runtime retest required.')
