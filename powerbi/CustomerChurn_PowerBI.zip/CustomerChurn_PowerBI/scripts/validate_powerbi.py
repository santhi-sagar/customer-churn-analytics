"""Offline Microsoft JSON schema validation plus bounded static model checks (not engine validation)."""
import json,re
from pathlib import Path
from jsonschema import Draft7Validator,RefResolver
ROOT=Path(__file__).resolve().parents[1]
registry=json.loads((ROOT/'schemas/registry.json').read_text(encoding='utf-8'))
checks=[];errors=[]
for p in ROOT.rglob('*'):
 if not p.is_file() or not (p.suffix in ['.json','.pbip','.pbir','.pbism'] or p.name=='.platform'):continue
 if any(x in p.relative_to(ROOT).parts for x in ['schemas','validation','scripts','StaticResources','.pbi']):continue
 if p.relative_to(ROOT).parts[0].startswith('CustomerChurnn'):continue
 obj=json.loads(p.read_text(encoding='utf-8'))
 url=obj.get('$schema')
 if not url:errors.append(str(p)+': missing schema');continue
 if url not in registry:
  checks.append({'file':str(p.relative_to(ROOT)),'schema':url,'valid':None,'reason':'Desktop-emitted schema unavailable in cached public registry; runtime validation recorded separately'})
  continue
 schema=registry[url]
 validator=Draft7Validator(schema,resolver=RefResolver(base_uri=url,referrer=schema,store=registry))
 issues=list(validator.iter_errors(obj))
 errors += [str(p.relative_to(ROOT))+': '+str(list(e.path))+' '+e.message for e in issues]
 checks.append({'file':str(p.relative_to(ROOT)),'schema':url,'valid':not issues})
table=(ROOT/'CustomerChurn.SemanticModel/definition/tables/ChurnSegments.tmdl').read_text(encoding='utf-8')
columns=set(re.findall(r"^\tcolumn '([^']+)'",table,re.M));measures=set(re.findall(r"^\tmeasure '([^']+)'",table,re.M))
# Every visual field must exist and every measure column dependency must resolve.
for p in (ROOT/'CustomerChurn.Report').rglob('visual.json'):
 j=json.loads(p.read_text(encoding='utf-8'))
 for role in j['visual'].get('query',{}).get('queryState',{}).values():
  for pr in role['projections']:
   k,v=next(iter(pr['field'].items()));assert v['Expression']['SourceRef']['Entity']=='ChurnSegments'
   assert v['Property'] in (measures if k=='Measure' else columns),(p,v)
for c in re.findall(r'ChurnSegments\[([^]]+)\]',table):assert c in columns,c
for m in re.findall(r'(?<![A-Za-z0-9_])\[([^]]+)\]', '\n'.join(re.findall(r'^\tmeasure .*$',table,re.M))):assert m in columns|measures,m
assert json.loads((ROOT/'CustomerChurn.Report/definition/version.json').read_text())['version']=='2.0.0'
assert not (columns & measures), 'Column/measure name collision'
pbip=json.loads((ROOT/'CustomerChurn.pbip').read_text());report=ROOT/pbip['artifacts'][0]['report']['path'];assert (report/'definition.pbir').is_file()
pbir=json.loads((report/'definition.pbir').read_text());assert (report/pbir['datasetReference']['byPath']['path']/'definition.pbism').is_file()
page_names=json.loads((report/'definition/pages/pages.json').read_text())['pageOrder']
for name in page_names:
 page=json.loads((report/'definition/pages'/name/'page.json').read_text());assert page['name']==name
 for p in (report/'definition/pages'/name/'visuals').rglob('visual.json'):
  j=json.loads(p.read_text());pos=j['position'];assert j['name']==p.parent.name;assert 0<=pos['x'] and 0<=pos['y'] and pos['x']+pos['width']<=page['width'] and pos['y']+pos['height']<=page['height']
assert 'customerID' not in table
out={'official_schema_documents_cached':len(registry),'schema_validated_files':len(checks),'schema_errors':errors,'schema_checks':checks,'static_checks':{'pbip_report_model_paths':'PASS','all_visual_fields_resolve':'PASS','all_DAX_column_and_measure_references_resolve':'PASS','page_order_names_and_visual_bounds':'PASS','no_customer_identifier_column':'PASS','aggregate_totals_reconcile':'PASS (build script)'},'not_tested':['Power BI Desktop open','Power Query engine refresh','TMDL and DAX engine compilation','visual rendering and interactive filtering']}
(ROOT/'validation/schema-validation.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='schema_checks'},indent=2))
assert not errors,errors
