"""Rebuild native PBIP from private IBM Telco CSV. No raw customer records are copied."""
import csv,json,sys,hashlib
from pathlib import Path
from collections import defaultdict
from decimal import Decimal
ROOT=Path(__file__).resolve().parents[1]
SOURCE=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT.parent/'data/private/telco.csv'
def write(p,obj):
 p=ROOT/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def text(p,s):
 p=ROOT/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf-8')
def schema(p):return 'https://developer.microsoft.com/json-schemas/fabric/'+p+'/schema.json'
S={k:schema(p) for k,p in {'pbip':'pbip/pbipProperties/1.0.0','pbir':'item/report/definitionProperties/2.0.0','pbism':'item/semanticModel/definitionProperties/1.0.0','visual':'item/report/definition/visualContainer/2.1.0','page':'item/report/definition/page/2.0.0','pages':'item/report/definition/pagesMetadata/1.0.0','report':'item/report/definition/report/2.0.0','version':'item/report/definition/versionMetadata/1.0.0'}.items()}

segments=list(csv.DictReader((ROOT.parent/'data/aggregates/segments.csv').open(encoding='utf-8-sig')))
summary={r['Metric']:float(r['Value']) for r in csv.DictReader((ROOT.parent/'data/aggregates/summary.csv').open())}
cols=['Dimension','Segment','Customer Count','Churned Count','Monthly Charges Sum']
data=[[r['Dimension'],r['Segment'],int(r['Customers']),int(r['Churned']),float(r['MonthlyCharges'])] for r in segments]
mtypes=['text','text','Int64.Type','Int64.Type','Currency.Type']
def mval(v):return json.dumps(v,ensure_ascii=False) if isinstance(v,str) else str(v)
expr='let\n    Source = #table(type table ['+', '.join('#"'+c+'" = '+t for c,t in zip(cols,mtypes))+'], {\n'+',\n'.join('        {'+', '.join(mval(v) for v in r)+'}' for r in data)+'\n    })\nin\n    Source'
text('power-query/ChurnSegments.pq',expr+'\n')
measures={
'Customers':('VAR D = IF(ISFILTERED(ChurnSegments[Dimension]), SELECTEDVALUE(ChurnSegments[Dimension], "Contract"), "Contract") RETURN CALCULATE(SUM(ChurnSegments[Customer Count]), KEEPFILTERS(ChurnSegments[Dimension] = D))','#,0'),
'Churned Customers':('VAR D = IF(ISFILTERED(ChurnSegments[Dimension]), SELECTEDVALUE(ChurnSegments[Dimension], "Contract"), "Contract") RETURN CALCULATE(SUM(ChurnSegments[Churned Count]), KEEPFILTERS(ChurnSegments[Dimension] = D))','#,0'),
'Churn Rate':('DIVIDE([Churned Customers], [Customers])','0.0%'),
'Monthly Charges':('VAR D = IF(ISFILTERED(ChurnSegments[Dimension]), SELECTEDVALUE(ChurnSegments[Dimension], "Contract"), "Contract") RETURN CALCULATE(SUM(ChurnSegments[Monthly Charges Sum]), KEEPFILTERS(ChurnSegments[Dimension] = D))','$#,0'),
'Average Monthly Charge':('DIVIDE([Monthly Charges], [Customers])','$0.00'),
'All Customers':('7043','#,0'),
'All Churned Customers':('1869','#,0'),
'All Churn Rate':('DIVIDE([All Churned Customers], [All Customers])','0.0%'),
'Observed Churned MRR':(str(summary['churned_monthly_charges']),'$#,0'),
'Report Context':('"IBM Telco sample | observed churn, not a forecast"',None),
'Revenue Definition':('"Observed churned MRR = sum of MonthlyCharges for Churn = Yes. Snapshot exposure only; not projected loss, ARR, or CLV. This headline is fixed to the full sample."',None),
'Data Limitations':('"No payment-delay field, dated churn events, acquisition cost, or future cashflows. Payment method does not show late payment. Independent segment summaries cannot establish joint segment effects."',None),
'Privacy and Refresh':('"17 embedded segment rows; no customer IDs. Refresh needs no credentials. Segment explorer defaults to Contract; choose one Dimension at a time. Multi-select falls back to Contract if included, otherwise blank."',None)
}
for dim in ['Contract','tenure_band','InternetService','PaymentMethod']:
 measures[dim+' Churn Rate']=('DIVIDE(CALCULATE(SUM(ChurnSegments[Churned Count]), ChurnSegments[Dimension] = "'+dim+'"), CALCULATE(SUM(ChurnSegments[Customer Count]), ChurnSegments[Dimension] = "'+dim+'"))','0.0%')
tmdl='table ChurnSegments\n'
for c,t in zip(cols,['string','string','int64','int64','decimal']):
 tmdl+="\n\tcolumn '"+c+"'\n\t\tdataType: "+t+"\n\t\tsourceColumn: "+c+'\n\t\tsummarizeBy: '+'none'+'\n'
 if t!='string':tmdl+='\t\tisHidden\n'
for name,(dax,fmt) in measures.items():
 tmdl+="\n\tmeasure '"+name+"' = "+dax+'\n'
 if fmt:tmdl+='\t\tformatString: '+fmt+'\n'
tmdl+='\n\tpartition ChurnSegments = m\n\t\tmode: import\n\t\tsource =\n'+''.join('\t\t\t'+l+'\n' for l in expr.splitlines())+'\n\tannotation PBI_ResultType = Table\n'
text('CustomerChurn.SemanticModel/definition/tables/ChurnSegments.tmdl',tmdl)
text('CustomerChurn.SemanticModel/definition/database.tmdl','database\n\tcompatibilityLevel: 1601\n')
text('CustomerChurn.SemanticModel/definition/model.tmdl','model Model\n\tculture: en-US\n\tdefaultPowerBIDataSourceVersion: powerBI_V3\n\tsourceQueryCulture: en-US\n\tdataAccessOptions\n\t\tlegacyRedirects\n\t\treturnErrorValuesAsNull\n\nref table ChurnSegments\n')
write('CustomerChurn.SemanticModel/definition.pbism',{'$schema':S['pbism'],'version':'4.0','settings':{'qnaEnabled':False}})
write('CustomerChurn.pbip',{'$schema':S['pbip'],'version':'1.0','artifacts':[{'report':{'path':'CustomerChurn.Report'}}],'settings':{'enableAutoRecovery':True}})
write('CustomerChurn.Report/definition.pbir',{'$schema':S['pbir'],'version':'4.0','datasetReference':{'byPath':{'path':'../CustomerChurn.SemanticModel'}}})
base='CustomerChurn.Report/definition/'
write(base+'version.json',{'$schema':S['version'],'version':'4.0.0'})
write(base+'report.json',{'$schema':S['report'],'themeCollection':{}})
pages=['overview','segments','methodology']
write(base+'pages/pages.json',{'$schema':S['pages'],'pageOrder':pages,'activePageName':'overview'})
for name,title in zip(pages,['Churn | Executive overview','Churn | Segment explorer','Definitions | Read before interpreting']):
 write(base+'pages/'+name+'/page.json',{'$schema':S['page'],'name':name,'displayName':title,'displayOption':'FitToPage','height':900,'width':1440})
def field(n,measure=False):return {'field':{('Measure' if measure else 'Column'):{'Expression':{'SourceRef':{'Entity':'ChurnSegments'}},'Property':n}},'queryRef':'ChurnSegments.'+n,'nativeQueryRef':n}
def lit(s):return {'expr':{'Literal':{'Value':"'"+s.replace("'","''")+"'"}}}
visual_count=0
def visual(page,name,typ,roles,x,y,w,h,title):
 global visual_count
 visual_count+=1
 obj={'$schema':S['visual'],'name':name,'position':{'x':x,'y':y,'width':w,'height':h,'z':visual_count,'tabOrder':visual_count},'visual':{'visualType':typ,'query':{'queryState':{r:{'projections':[field(n,m) for n,m in fields]} for r,fields in roles.items()}},'visualContainerObjects':{'title':[{'properties':{'show':lit('true'),'text':lit(title),'fontSize':{'expr':{'Literal':{'Value':'13D'}}}}}]} ,'drillFilterOtherVisuals':True}}
 # Boolean literals must be booleans, not strings.
 obj['visual']['visualContainerObjects']['title'][0]['properties']['show']={'expr':{'Literal':{'Value':'true'}}}
 write(base+'pages/'+page+'/visuals/'+name+'/visual.json',obj)
def card(p,n,x,y,w=340,h=120,title=None):visual(p,n.lower().replace(' ','_'),'card',{'Values':[(n,True)]},x,y,w,h,title or n)
def slicer(p,n,x,y,w=300):visual(p,'filter_'+n.lower().replace(' ','_'),'slicer',{'Values':[(n,False)]},x,y,w,115,n)
def bar(p,n,m,x,y,w=680,h=260):visual(p,(n+'_'+m).lower().replace(' ','_'),'clusteredBarChart',{'Category':[(n,False)],'Y':[(m,True)]},x,y,w,h,m+' by '+n)

def textbox(page,name,value,x,y,w,h,title):
 visual(page,name,'textbox',{},x,y,w,h,title)
 p=base+'pages/'+page+'/visuals/'+name+'/visual.json';obj=json.loads((ROOT/p).read_text())
 obj['visual'].pop('query');obj['visual']['objects']={'general':[{'properties':{'paragraphs':[{'textRuns':[{'value':value,'textStyle':{'fontFamily':'Segoe UI','fontSize':'16pt'}}]}]}}]};write(p,obj)
textbox('overview','header','IBM Telco customer churn | full-sample snapshot',20,5,1400,80,'CUSTOMER CHURN')
for i,(n,title) in enumerate([('All Customers','Customers'),('All Churned Customers','Churned customers'),('All Churn Rate','Churn rate'),('Observed Churned MRR','Observed churned MRR | not forecast')]):card('overview',n,20+355*i,100,title=title)
for dim,title,x,y in [('Contract','Contract',20,240),('tenure_band','Tenure',740,240),('InternetService','Internet service',20,550),('PaymentMethod','Payment method',740,550)]:
 visual('overview',dim.lower(),'clusteredBarChart',{'Category':[('Segment',False)],'Y':[(dim+' Churn Rate',True)]},x,y,680,285,'Churn rate by '+title)
textbox('segments','header','Choose ONE Dimension, then a Segment. No cross-dimension filters: these are independent summaries. With no Dimension selected, measures use Contract.',20,5,1400,100,'SEGMENT EXPLORER')
slicer('segments','Dimension',20,120,680);slicer('segments','Segment',740,120,680)
for i,n in enumerate(['Customers','Churned Customers','Churn Rate','Average Monthly Charge']):card('segments',n,20+355*i,270)
for name,m,x in [('Churn rate','Churn Rate',20),('Churned customers','Churned Customers',740)]:
 visual('segments',m.lower().replace(' ','_')+'_chart','clusteredBarChart',{'Category':[('Segment',False)],'Y':[(m,True)]},x,410,680,260,name+' | selected dimension')
visual('segments','segment_details','tableEx',{'Values':[('Segment',False)]+[(n,True) for n in ['Customers','Churned Customers','Churn Rate','Monthly Charges']]},20,690,1400,190,'Independent segments | never add dimensions')
for i,(n,title) in enumerate([('Report Context','Scope'),('Revenue Definition','Revenue interpretation'),('Data Limitations','No payment-delay or CLV claim'),('Privacy and Refresh','Refresh and privacy')]):textbox('methodology',n.lower().replace(' ','_'),json.loads(measures[n][0]),30,20+210*i,1380,180,title)
text('measures.dax','\n\n'.join("MEASURE 'ChurnSegments'["+n+'] = '+d for n,(d,f) in measures.items())+'\n')

out={'source':'IBM Telco sample via approved aggregate CSVs','customers':7043,'churned_customers':1869,'churn_rate':summary['churn_rate'],'observed_churned_mrr':summary['churned_monthly_charges'],'aggregate_rows':len(data),'minimum_group_size':min(r[2] for r in data),'embedded_columns':cols,'pages':len(pages),'visuals':visual_count,'desktop_open_refresh_render_test':'NOT RUN','aggregation_guard':'Every dynamic count/charge measure filters one Dimension; default Contract.'}
for dim in {r[0] for r in data}:
 assert sum(r[2] for r in data if r[0]==dim)==7043
 assert sum(r[3] for r in data if r[0]==dim)==1869
write('validation/data-summary.json',out)
print(json.dumps(out,indent=2))

# Overview charts summarize independent dimensions; do not imply joint filtering.
p=ROOT/base/'pages/overview/page.json'
j=json.loads(p.read_text())
names=[v.parent.name for v in (p.parent/'visuals').rglob('visual.json')]
j['visualInteractions']=[{'source':a,'target':b,'type':'NoFilter'} for a in names for b in names if a!=b]
write(base+'pages/overview/page.json',j)

# Match current Microsoft report loader scaffold after generating definitions.
import runpy
runpy.run_path(str(ROOT/"scripts/fix_report_compatibility.py"), run_name="__main__")
